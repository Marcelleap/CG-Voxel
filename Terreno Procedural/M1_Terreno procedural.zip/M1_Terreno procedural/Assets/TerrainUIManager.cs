using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // Necessário para manipular UI elements

public class TerrainUIManager : MonoBehaviour
{
    public TerrainGenerator terrainGenerator;
    public Slider sizeXSlider;
    public Slider sizeZSlider;
    public Slider heightSlider;
    public Slider entropySlider;
    public Text sizeXValue;
    public Text sizeZValue;
    public Text heightValue;
    public Text entropyValue;
    public Button resetButton;
    public Dropdown voxelDropdown;
    public Dropdown gradientDropdown; // Dropdown para os gradientes

    void Start()
    {
        sizeXSlider.value = terrainGenerator.xSize;
        sizeZSlider.value = terrainGenerator.zSize;
        heightSlider.value = terrainGenerator.height;
        entropySlider.value = terrainGenerator.entropy;

        UpdateUI();

        sizeXSlider.onValueChanged.AddListener(delegate { OnSizeXChanged(); });
        sizeZSlider.onValueChanged.AddListener(delegate { OnSizeZChanged(); });
        heightSlider.onValueChanged.AddListener(delegate { OnHeightChanged(); });
        entropySlider.onValueChanged.AddListener(delegate { OnEntropyChanged(); });

        resetButton.onClick.AddListener(OnResetClicked);

        voxelDropdown.onValueChanged.AddListener(delegate { OnVoxelTypeChanged(); });
        gradientDropdown.onValueChanged.AddListener(delegate { OnGradientChanged(); });

        // Configurar o dropdown de gradientes com as opções
        List<string> gradientOptions = new List<string> { "Padrão", "Unicórnio", "Brutal", "Light", "Black" };
        gradientDropdown.AddOptions(gradientOptions);
    }

    public void OnSizeXChanged()
    {
        terrainGenerator.SetSizeX(sizeXSlider.value);
        UpdateUI();
    }

    public void OnSizeZChanged()
    {
        terrainGenerator.SetSizeZ(sizeZSlider.value);
        UpdateUI();
    }

    public void OnHeightChanged()
    {
        terrainGenerator.SetHeight(heightSlider.value);
        UpdateUI();
    }

    public void OnEntropyChanged()
    {
        terrainGenerator.SetEntropy(entropySlider.value);
        UpdateUI();
    }

    public void OnResetClicked()
    {
        terrainGenerator.ResetToDefaultValues();
        sizeXSlider.value = terrainGenerator.xSize;
        sizeZSlider.value = terrainGenerator.zSize;
        heightSlider.value = terrainGenerator.height;
        entropySlider.value = terrainGenerator.entropy;

        voxelDropdown.value = 0;
        gradientDropdown.value = 0; // Reseta o gradiente para "Padrão"
        UpdateUI();
    }

    public void OnVoxelTypeChanged()
    {
        terrainGenerator.SetVoxelType(voxelDropdown.value);
    }

    public void OnGradientChanged()
    {
        terrainGenerator.SetGradient(gradientDropdown.value); // Atualiza o gradiente selecionado
    }

    void UpdateUI()
    {
        sizeXValue.text = sizeXSlider.value.ToString();
        sizeZValue.text = sizeZSlider.value.ToString();
        heightValue.text = heightSlider.value.ToString("F1");
        entropyValue.text = entropySlider.value.ToString("F1");
    }
}

