using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class TerrainGenerator : MonoBehaviour
{
    public int xSize = 50; // Largura do terreno
    public int zSize = 50; // Profundidade do terreno
    public float height = 10; // Altura dos Voxels
    public float entropy = 5; // Caoticidade do terreno
    public Gradient[] gradients; // Array de 5 gradientes
     private Gradient currentGradient;
   public GameObject voxel;  // Prefab do voxel (Cubo)

    private readonly List<GameObject> buffer = new(); // Buffer de voxels instanciados


    public GameObject cuboPrefab; // Prefab do cubo
    public GameObject esferaPrefab; // Prefab da esfera
    public GameObject cilindroPrefab; // Prefab do cilindro


    public void Start()
    {
        voxel = cuboPrefab; // O cubo será o voxel padrão
        currentGradient = gradients[0]; // Definindo o gradiente padrão
        CreateMesh(); // Criação da malha
    }

    public void SetVoxelType(int voxelType)
    {
        switch (voxelType)
        {
            case 0:
                voxel = cuboPrefab; // Tipo cubo
                break;
            case 1:
                voxel = esferaPrefab; // Tipo esfera
                break;
            case 2:
                voxel = cilindroPrefab; // Tipo cilindro
                break;
            default:
                voxel = cuboPrefab; // Caso inválido, volta ao cubo
                break;
        }
        ResetTerrain(); // Recria o terreno com o novo tipo de voxel
    }

    public void SetGradient(int gradientIndex)
    {
        if (gradientIndex >= 0 && gradientIndex < gradients.Length)
        {
            currentGradient = gradients[gradientIndex];
        }
        ResetTerrain();
    }

    public void CreateMesh()
    {

        for (int z = 0; z <= zSize; z++)
        {
            for (int x = 0; x <= xSize; x++)
            {
                float noiseX = (x / (float)xSize) * entropy; // Coordenada X do Perlin
                float noiseZ = (z / (float)zSize) * entropy; // Coordenada Z do Perlin
                float y = Mathf.PerlinNoise(noiseX, noiseZ) * height; // Altura baseada no Perlin Noise

                Vector3 pos = new Vector3(x, Mathf.Round(y), z); // Posição do voxel
                GameObject obj = Instantiate(voxel, pos, Quaternion.identity); // Instancia voxel baseado na forma atual
                Material m = obj.GetComponent<MeshRenderer>().material;
                m.color = currentGradient.Evaluate(y / this.height); // Aplicar o gradiente selecionado

                buffer.Add(obj);

            }
        }
    }

    public void ResetTerrain()
    {
        ClearVoxels(); // Limpa os voxels existentes antes de recriar
        CreateMesh(); // Recria a malha
    }


    // Limpar voxels existentes
    public void ClearVoxels()
    {
        foreach (GameObject obj in buffer)
        {
            Destroy(obj);
        }
        buffer.Clear(); // Limpa a lista de voxels
    }

    public void SetSizeX(float value)
    {
        xSize = (int)value;
        ResetTerrain();
    }

    public void SetSizeZ(float value)
    {
        zSize = (int)value;
        ResetTerrain();
    }

    public void SetHeight(float value)
    {
        height = value;
        ResetTerrain();
    }

    public void SetEntropy(float value)
    {
        entropy = value;
        ResetTerrain();
    }

    public void ResetToDefaultValues()
    {
        xSize = 50; // Defina o valor padrão
        zSize = 50; // Defina o valor padrão
        height = 10; // Defina o valor padrão
        entropy = 5; // Defina o valor padrão
        voxel = cuboPrefab; // Reseta o voxel para cubo
         currentGradient = gradients[0]; // Volta ao gradiente padrão
        ResetTerrain(); // Limpa e recria o terreno
    }
}
